import "./navbar.css";

const Navbar = () => {
  return (
    <>
      <div className="header"></div>
    </>
  );
};

export default Navbar;
